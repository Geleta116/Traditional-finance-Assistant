import 'package:flutter/material.dart';
import 'myApp.dart';

main() {
  runApp(MyApp());
}
