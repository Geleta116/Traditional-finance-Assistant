class User{
  String name;
  String username;
  bool haveWon;
  String joinedAt;
  User({required this.name, required this.username,  this.haveWon = false, this.joinedAt = ''});
  
}
