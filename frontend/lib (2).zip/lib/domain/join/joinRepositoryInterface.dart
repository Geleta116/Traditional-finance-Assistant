

import 'package:traditional_financial_asistant/domain/join/join.dart';

abstract class JoinRepositoryInterface {
  Future<void> joined(Join join);

}
