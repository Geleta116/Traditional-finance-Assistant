// import 'package:go_router/go_router.dart';
// import 'package:traditional_finance_assistant__app/presentation/ekub/createEqub.dart';
// import 'waiting_screen.dart';
// import 'package:traditional_finance_assistant__app/presentation/auth/login.dart';
// import 'package:traditional_finance_assistant__app/presentation/register/signup_screen.dart';
// import 'package:traditional_finance_assistant__app/welcome.dart';
// class Routing {
//    static GoRouter appRouting = GoRouter(routes: [
//     GoRoute(
//       path: '/',
//       name: 'waiting',
//       builder: (context, state) =>  Login(),
//     ),
//     GoRoute(
//         path: "/login",
//         name: "login",
//         builder: (context, state) =>  Login()),
//     GoRoute(
//         path: "/signup",
//         name: "signup",
//         builder: (context, state) => SignupScreen()),
//     GoRoute(path: "/ekub",
//      name: "ekub", 
//      builder: (context, state) => CreateEqubScreen()),

//      GoRoute(path: "/landing",name:  "landing",builder: (context, state) =>  Welcome())

//   ]);
// }
